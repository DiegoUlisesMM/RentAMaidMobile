import { View, Text } from 'react-native'
import React from 'react'

export default function Favoritos() {
  return (
    <View>
      <Text>Favoritos</Text>
    </View>
  )
}