import { View, Text } from 'react-native'
import React from 'react'

export default function Account() {
  return (
    <View>
      <Text>Account</Text>
    </View>
  )
}